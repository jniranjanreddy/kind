#!/bin/bash
set -e

echo "🚀 Installing Airflow on Kind - Complete Setup"
echo "================================================"

# Step 0: Add Helm repository
echo "📚 Adding Airflow Helm repository..."
helm repo add apache-airflow https://airflow.apache.org
helm repo update
echo "✅ Helm repo added and updated"

# Step 1: Create PersistentVolumes
echo ""
echo "📦 Creating PersistentVolumes..."
kubectl apply -f kind-persistent-volumes.yaml
kubectl get pv
echo "✅ PersistentVolumes created"

# Step 2: Create namespace
echo ""
echo "📁 Creating namespace..."
kubectl create namespace airflow
echo "✅ Namespace created"

# Step 3: Install Airflow
echo ""
echo "⚙️  Installing Airflow with Helm..."
helm install airflow apache-airflow/airflow \
  --namespace airflow \
  --values airflow-values-kind.yaml \
  --timeout 20m

echo "✅ Airflow installed"

# Step 4: Wait for PostgreSQL
echo ""
echo "⏳ Waiting for PostgreSQL to be ready..."
kubectl wait --for=condition=ready pod -l component=postgresql -n airflow --timeout=300s
echo "✅ PostgreSQL ready"

# Step 5: Run database migration
echo ""
echo "🗄️  Running database migration..."
kubectl apply -f manual-migration-job.yaml
echo "⏳ Waiting for migration to complete..."
kubectl wait --for=condition=complete job/airflow-manual-migration -n airflow --timeout=300s
echo "✅ Database migration complete"

# Step 6: Wait for all pods
echo ""
echo "⏳ Waiting for all Airflow pods to be ready..."
sleep 10
kubectl get pods -n airflow

# Step 7: Show final status
echo ""
echo "================================================"
echo "✅ Installation Complete!"
echo "================================================"
echo ""
echo "📊 Cluster Status:"
kubectl get pods -n airflow
echo ""
kubectl get pv
echo ""
echo "🌐 Access Airflow UI:"
echo "   kubectl port-forward svc/airflow-webserver 8080:8080 -n airflow"
echo "   Then open: http://localhost:8080"
echo "   Login: admin / admin"
echo ""
echo "🌸 Access Flower UI (optional):"
echo "   kubectl port-forward svc/airflow-flower 5555:5555 -n airflow"
echo "   Then open: http://localhost:5555"
echo ""
echo "📝 View logs:"
echo "   kubectl logs -f deployment/airflow-scheduler -n airflow"
echo ""
echo "🧹 Clean up migration job (optional):"
echo "   kubectl delete job airflow-manual-migration -n airflow"
echo ""
